<?php

$xportlist = stream_get_transports();
print_r($xportlist);

