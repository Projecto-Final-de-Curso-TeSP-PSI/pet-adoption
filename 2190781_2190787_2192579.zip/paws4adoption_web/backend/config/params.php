<?php
return [
    'adminEmail' => 'paws4adoption@gmail.com',
];
