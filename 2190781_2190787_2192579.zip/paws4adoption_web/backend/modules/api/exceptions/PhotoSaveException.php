<?php

namespace backend\modules\api\exceptions;

use yii\base\Exception;

class PhotoSaveException extends Exception
{

}