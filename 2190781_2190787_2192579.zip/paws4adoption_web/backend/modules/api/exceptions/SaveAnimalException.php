<?php

namespace backend\modules\api\exceptions;

use yii\base\Exception;

class SaveAnimalException extends Exception
{

}