<?php

namespace backend\modules\api\exceptions;

use yii\base\Exception;

class PhotoUploadException extends Exception
{


}