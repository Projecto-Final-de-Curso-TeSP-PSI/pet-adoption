<?php

return[
    [
        'id' => 1,
        'chipId' => '123456789123456',
        'createdAt' => '2020-05-02 00:00:00',
        'description' => 'Gato em fuga',
        'nature_id' => 4,
        'fur_length_id' => 2,
        'fur_color_id' => 'Leiria',
        'size_id' => 1,
        'sex' => 'M',
        'name' => 'Pucci'
    ],
    [
        'id' => 2,
        'chipId' => '123456789456789',
        'createdAt' => '2020-05-02 00:00:00',
        'description' => 'Gato no cio',
        'nature_id' => 1,
        'fur_length_id' => 2,
        'fur_color_id' => 3,
        'size_id' => 2,
        'sex' => 'M',
        'name' => 'Pucci'
    ],
];
