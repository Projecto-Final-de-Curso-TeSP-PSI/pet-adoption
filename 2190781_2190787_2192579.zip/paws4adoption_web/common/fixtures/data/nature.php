<?php

return[
    [
        'id' => 1,
        'name' => 'Cão',
        'parent_nature_id' => null
    ],
    [
        'id' => 2,
        'name' => 'Gato',
        'parent_nature_id' => null
    ],
    [
        'id' => 3,
        'name' => 'Persa',
        'parent_nature_id' => 2
    ],
    [
        'id' => 4,
        'name' => 'Boxer',
        'parent_nature_id' => 1
    ],
    [
        'id' => 5,
        'name' => 'Jack Russel',
        'parent_nature_id' => 2
    ],
];

