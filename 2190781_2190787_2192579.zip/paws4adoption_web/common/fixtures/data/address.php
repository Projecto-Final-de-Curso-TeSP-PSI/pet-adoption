<?php

return[
    'address1' => [
        'id' => 1,
        'street' => 'Rua de cima',
        'door_number' => '34',
        'floor' => '1º',
        'postal_code' => 2400,
        'street_code' => 330,
        'city' => 'Leiria',
        'district_id' => 1,
    ],
    'address2' => [
        'id' => 2,
        'street' => 'Rua de cima',
        'door_number' => '34',
        'floor' => '1º',
        'postal_code' => 2400,
        'street_code' => 330,
        'city' => 'Leiria',
        'district_id' => 1,
    ],
    'address3' => [
        'id' => 3,
        'street' => 'Rua dos Gatos',
        'door_number' => '22',
        'floor' => '',
        'postal_code' => 2395,
        'street_code' => 666,
        'city' => 'Minde',
        'district_id' => 7,
    ],
    'address10' => [
        'id' => 10,
        'street' => 'Rua dos Gatos',
        'door_number' => '22',
        'floor' => '',
        'postal_code' => 2395,
        'street_code' => 666,
        'city' => 'Minde',
        'district_id' => 7,
    ],
];
