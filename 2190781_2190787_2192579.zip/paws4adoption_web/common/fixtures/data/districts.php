<?php

return[
    'distric1' => [
        'id' => 1,
        'name' => 'Leiria',
    ],
    'district2' => [
        'id' => 2,
        'name' => 'Santarém',
    ],
    'district3' => [
        'id' => 3,
        'name' => 'Coimbra',
    ],
    'district4' => [
        'id' => 4,
        'name' => 'Lisboa',
    ],
    'district5' => [
        'id' => 5,
        'name' => 'Faro',
    ],
    'district6' => [
        'id' => 6,
        'name' => 'Setúbal',
    ],
    'district7' => [
        'id' => 7,
        'name' => 'Évora',
    ],
    'district8' => [
        'id' => 8,
        'name' => 'Beja',
    ],
];

