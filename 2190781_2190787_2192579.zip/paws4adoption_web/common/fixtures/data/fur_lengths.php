<?php

return[
    [
        'id' => 1,
        'fur_length' => 'Curto',
    ],
    [
        'id' => 2,
        'fur_length' => 'Medio',
    ],
    [
        'id' => 3,
        'fur_length' => 'Longo',
    ]
];

