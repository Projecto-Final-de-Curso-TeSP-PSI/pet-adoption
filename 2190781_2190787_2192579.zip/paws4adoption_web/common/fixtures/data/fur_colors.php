<?php

return[
    [
        'id' => 1,
        'fur_color' => 'Branco',
    ],
    [
        'id' => 2,
        'fur_color' => 'Preto',
    ],
    [
        'id' => 3,
        'fur_color' => 'Castanho',
    ],
];

