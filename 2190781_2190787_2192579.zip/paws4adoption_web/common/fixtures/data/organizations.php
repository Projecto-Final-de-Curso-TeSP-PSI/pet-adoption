<?php

return [
    'organization1' => [
        'name' => 'Associação Zoófila Leiria',
        'nif' => '505126580',
        'email' => 'azl@gmail.com',
        'phone' => '912356896',
        'address_id' => 1,
        'founder_id' => 3,
        'status' => \common\models\Organization::STATUS_ACTIVE,
    ],
    'organization2' => [
        'name' => 'Apa',
        'nif' => '525689568',
        'email' => 'apa@gmail.com',
        'phone' => '912568968',
        'address_id' => 2,
        'founder_id' => 3,
        'status' => \common\models\Organization::STATUS_ACTIVE,
    ],
    'organization3' => [
        'name' => 'Apa',
        'nif' => '525689569',
        'email' => 'apa@gmail2.com',
        'phone' => '912568968',
        'address_id' => 3,
        'founder_id' => 3,
        'status' => \common\models\Organization::STATUS_ACTIVE,
    ],
];
