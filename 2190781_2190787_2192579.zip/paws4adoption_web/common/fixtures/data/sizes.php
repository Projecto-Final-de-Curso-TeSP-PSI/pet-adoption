<?php

return[
    [
        'id' => 1,
        'size' => 'Pequeno',
    ],
    [
        'id' => 2,
        'size' => 'Médio',
    ],
    [
        'id' => 3,
        'size' => 'Grande',
    ]
];

