<?php

namespace common\fixtures;


use yii\test\ActiveFixture;

class DistrictFixture extends ActiveFixture
{
    public $modelClass = 'common\models\District';
}