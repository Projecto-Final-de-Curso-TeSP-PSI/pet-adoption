<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user common\models\user */

$verifyLink = Yii::$app->urlManager->createAbsoluteUrl(['api/users/validation/'. $user->verification_token]);
?>
<div class="verify-email">
    <p>Olá <?= Html::encode($user->username) ?>,</p>

    <p>Clique no link abaixo para validar o seu email:</p>

    <p><?= Html::a(Html::encode($verifyLink), $verifyLink) ?></p>
</div>
