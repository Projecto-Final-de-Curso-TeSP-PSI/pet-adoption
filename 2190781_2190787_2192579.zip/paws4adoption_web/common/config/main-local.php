<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=paws4adoption',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@commoNmail',
            'useFileTransport' => false,
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.gmail.com', //Se falhar usar ip v4…
                'username' => 'paws4adoption@gmail.com',
                'password' => 'Sporting123',
                'port' => '587', //465 ou 587',
                'encryption' => 'tls', //ssl ou tls
            ],
        ],
    ],
];
