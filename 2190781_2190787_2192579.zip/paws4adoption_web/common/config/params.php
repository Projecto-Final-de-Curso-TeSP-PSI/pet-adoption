<?php
return [
    'adminEmail' => 'paws4adoption@gmail.com',
    'supportEmail' => 'support@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Formulario de Contacto',
    'user.passwordResetTokenExpire' => 3600,
    'user.passwordMinLength' => 8,
];
