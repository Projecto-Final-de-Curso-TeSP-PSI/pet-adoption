<?php
return [
    'components' => [
        'db' => [
            'dsn' => 'mysql:host=localhost;dbname=paws4adoption_test',
        ],
    ],
];
