<div class="flex-grow-1"></div>
<footer class="footer mt-1">
    <p>Copyright © 2019 Plab. All rights reserved</p>
</footer>